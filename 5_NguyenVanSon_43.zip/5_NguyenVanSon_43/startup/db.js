const mongoose = require('mongoose');
const winston = require('winston');

module.exports = () => {
    mongoose.connect('mongodb+srv://KiemTraNodeJs2:nguyenvanson12345@cluster0.uien8.mongodb.net/KiemTraNodeJs2?retryWrites=true&w=majority', {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        useFindAndModify: true,
        useCreateIndex: true
    }).then(() => winston.info('MongoDb đã kết nối thành công ...'));
}
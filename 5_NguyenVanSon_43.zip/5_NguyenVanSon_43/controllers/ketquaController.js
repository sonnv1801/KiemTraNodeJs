const { Ketqua , validate } = require('../models/ketqua');

const getAllKetQuas = async (req, res, next) => {
    const listketqua = await Ketqua.find().exec();
    res.render('ketqualist', {
        ketquas: listketqua
    });
}

const getAddKetQua = (req, res, next) => {
    res.render('addKetqua');
}

const addKetQua = async (req, res, next) => {
    const {error} = validate(req.body);
    if(error) return res.status(422).send(error.details[0].message);
    const data = req.body;
    let ketqua = await new Ketqua({
        maSv: data.maSv,
        maMh: data.maMh,
        diemThi: data.diemThi,
    });
    ketqua = await ketqua.save();
    res.redirect('/');
}

const getUpdateKetQua = async (req, res, next) => {
    try {
        const id = req.params.id;
        const oneketqua = await Ketqua.findById(id).exec();
        res.render('updateKetqua', {
            ketqua: oneketqua
        });
    } catch (error) {
        res.status(400).send(error.message);
    }
}

const updateKetQua = async(req, res, next) => {
    const {error} = validate(req.body);
    if (error) return res.status(422).send(error.details[0].message);
    const id = req.params.id;
    const data = req.body;
    let ketqua = await Ketqua.findByIdAndUpdate(id, {
        maSv: data.maSv,
        maMh: data.maMh,
        diemThi: data.diemThi,
    }, {new: true});
    if(!ketqua) return res.status(404).send('KetQua với id đã cho không tìm thấy');

    res.redirect('/');
}

const getDeleteKetQua = async (req, res, next) => {
    try {
        const id = req.params.id;
        const oneketqua = await Ketqua.findById(id).exec();
        res.render('deleteKetqua', {
            ketqua: oneketqua
        });
    } catch (error) {
        res.status(400).send(error.message);
    }
}

const deleteKetQua = async (req, res, next) => {
    try {
        const id = req.params.id;
        const ketqua = await Ketqua.findByIdAndRemove(id);
        if(!ketqua) return res.status(404).send('KetQua với id đã cho không tìm thấy');
        res.redirect('/');        
    } catch (error) {
        res.status(400).send(error.message);
    }
}


module.exports = {
    getAllKetQuas,
    getAddKetQua,
    addKetQua,
    getUpdateKetQua,
    updateKetQua,
    getDeleteKetQua,
    deleteKetQua,
}
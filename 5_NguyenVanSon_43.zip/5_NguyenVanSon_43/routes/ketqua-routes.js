const express = require('express');
const { getAllKetQuas, getAddKetQua, addKetQua, getUpdateKetQua, updateKetQua, getDeleteKetQua, deleteKetQua } = require('../controllers/ketquaController');


const router = express.Router();

router.get('/', getAllKetQuas);
router.get('/addKetqua', getAddKetQua);
router.post('/addKetqua', addKetQua);
router.get('/updateKetqua/:id', getUpdateKetQua);
router.post('/updateKetqua/:id', updateKetQua);
router.get('/deleteKetQua/:id', getDeleteKetQua);
router.post('/deleteKetQua/:id', deleteKetQua);



module.exports = {
    ketquas: router
}
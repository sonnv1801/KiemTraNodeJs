const mongoose = require('mongoose');
const Joi = require('joi');

const ketquaSchema = new mongoose.Schema({
    maSv: {
        type: Number,
        required: true
    },
    maMh: {
        type: String,
        required: true
    }, 
    diemThi: {
        type: Number,
        min: 0,
        max: 10,
        required: true
    },
});

const Ketqua = mongoose.model('Ketqua', ketquaSchema);

const validateKetqua = (ketqua) => {
    const schema = {
        maSv: Joi.number().required(),
        maMh: Joi.string().required(),
        diemThi: Joi.number().min(0).max(10).required(),
    }

    return Joi.validate(ketqua, schema);
}


module.exports.Ketqua = Ketqua;
module.exports.validate = validateKetqua;